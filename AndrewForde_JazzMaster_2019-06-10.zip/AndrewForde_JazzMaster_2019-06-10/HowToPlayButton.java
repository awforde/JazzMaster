import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HowToPlayButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HowToPlayButton extends Actor
{
    /**
     * Act - do whatever the HowToPlayButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (Greenfoot.mouseClicked(this)) // if the how to play button is clicked,
        {
            //add the how to play screen on top of everything else
            getWorld().addObject(new HowToPlayScreen(), (getWorld().getWidth())/2,(getWorld().getHeight())/2);
            
        }
    }    
}
