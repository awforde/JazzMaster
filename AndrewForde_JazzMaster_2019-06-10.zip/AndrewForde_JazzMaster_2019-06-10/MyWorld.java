import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    private ScoreCounter scoreCounter;
    private HitCounter hitCounter;
    private MissCounter missCounter;
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        super(1200, 900, 1); // create the world, 1200 x 900 pixels
        Greenfoot.setSpeed(46);
        setBackground("JazzMaster_TitleScreen.png");
        StartButton startButton = new StartButton();
        addObject (startButton, getWidth()/2, (getHeight()/2) + 100);
    }
    
    
    public void act()
    {
        if (getObjects(Level1Song.class).size() == 1 && getObjects(ScoreCounter.class).size() == 0)
        {
            scoreCounter = new ScoreCounter(); // add a score counter
            addObject (scoreCounter, 225, 650); // place the score counter in the world
            
            hitCounter = new HitCounter(); // add a hit counter
            addObject(hitCounter, 150, 750);
            
            missCounter = new MissCounter(); // add a miss counter
            addObject(missCounter, 450, 750);
        }
    }
    
    
    public ScoreCounter getScore() // used to reference the score counter
    {
        return scoreCounter;
    }
    
    public HitCounter getHits() // used to reference the hit counter
    {
        return hitCounter;
    }
    
    public MissCounter getMisses() // used to reference the miss counter
    {
        return missCounter;
    }
}
