import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level1Song here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level1Song extends Actor
{
    boolean gameTime = false;
    int sequence = 0;
    int met1 = 0;
    int sequenceCount = 0;
    
    GreenfootSound level1Track = new GreenfootSound("Level1Track.mp3");
    
    
    
    
        public void act() 
        {
            if (Greenfoot.getKey() == "enter" && gameTime == false)
            {
                
                gameTime = true;
                level1Track.play();
            }
            else if (gameTime == true)
            {
                if (sequenceCount == 10)
                {
                    sequence = 10;
                    sequenceCount += 1;
                }
                else if (sequence == 10)
                {
                    // do nothing for a bit
                    met1 += 1;
                    if (met1 == 100)
                    {
                        met1 = 0;
                        sequence = 11;
                    }
                }
                else if (sequence == 11)        // Transition to the Final Score Screen
                {
                    gameTime = false;
                    level1Track.stop();
                    getWorld().setBackground(new GreenfootImage("JazzMaster_ScoreScreen.png"));
                    
                    getWorld().addObject(new FinalScore(), 900, 300);//add the final score display
                    getWorld().addObject(new FinalHitCounter(), 900, 400);// add the final hit counter
                    getWorld().addObject(new FinalMissCounter(), 900, 475); // add the final Miss counter
                    getWorld().addObject(new Rank(), 900, 550);// add the rank display
                    getWorld().addObject(new BackToStartMenu(), 900, 700); // add a back button, returning to the start menu
                    
                    
                    getWorld().removeObjects(getWorld().getObjects(HitBar.class)); // remove the hit bar
                    getWorld().removeObjects(getWorld().getObjects(HitCounter.class)); // remove the hit counter
                    getWorld().removeObjects(getWorld().getObjects(MissCounter.class)); // remove the miss counter
                    getWorld().removeObjects(getWorld().getObjects(ScoreCounter.class)); // remove the score counter
                    
                    getWorld().removeObject(this);
                }
                else if (sequence == 0)
                {
                    seq0();
                }
                else if (sequence == 1)
                {
                    seq1();
                }
                else if (sequence == 2)
                {
                    seq2();
                }
                else if (sequence == 3)
                {
                    seq3();
                }
            }
        }    

        public void seq0()
        {
            met1 += 1;
            if (met1 == 100)
            {
                met1 = 0;
                sequence = 1;
            }
        }
        
        
        public void seq1()
        {
            met1 += 1;
            if (met1 == 10)
            {
                getWorld().addObject(new LeftArrow(), 675, 100);
            }
            else if (met1 == 30)
            {
                getWorld().addObject(new One(), 675, 100);
            }
            else if (met1 == 40)
            {
                getWorld().addObject(new Three(), 975, 100);
            }
            else if (met1 == 60)
            {
                getWorld().addObject(new Two(), 825, 100);
            }
            else if (met1 == 80)
            {
                getWorld().addObject(new Four(), 1125, 100);
            }
            else if (met1 == 100)
            {
                getWorld().addObject(new LeftArrow(), 675, 100);
            }
            else if (met1 == 110)
            {
                getWorld().addObject(new DownArrow(), 825, 100);
            }
            else if (met1 == 130)
            {
                getWorld().addObject(new LeftArrow(), 675, 100);
            }
            else if (met1 == 160)
            {
                met1 = 0;
                sequenceCount += 1;
                sequence = Greenfoot.getRandomNumber(3) + 1;
            }
        } 
        public void seq2()
        {
            met1 += 1;
            if (met1 == 10)
            {
                getWorld().addObject(new Four(), 1125, 100);
            }
            else if (met1 == 30)
            {
                getWorld().addObject(new RightArrow(), 1125, 100);
            }
            else if (met1 == 40)
            {
                getWorld().addObject(new Three(), 975, 100);
            }
            else if (met1 == 60)
            {
                getWorld().addObject(new Two(), 825, 100);
            }
            else if (met1 == 70)
            {
                getWorld().addObject(new Three(), 975, 100);
            }
            else if (met1 == 80)
            {
                getWorld().addObject(new Four(), 1125, 100);
            }
            else if (met1 == 120)
            {
                getWorld().addObject(new DownArrow(), 825, 100);
            }
            else if (met1 == 130)
            {
                getWorld().addObject(new LeftArrow(), 675, 100);
            }
            else if (met1 == 160)
            {
                met1 = 0;
                sequenceCount += 1;
                sequence = Greenfoot.getRandomNumber(3) + 1;
            }
        }
        public void seq3()
        {
            met1 += 1;
            if (met1 == 10)
            {
                getWorld().addObject(new RightArrow(), 1125, 100);
            }
            else if (met1 == 20)
            {
                getWorld().addObject(new UpArrow(), 975, 100);
            }
            else if (met1 == 40)
            {
                getWorld().addObject(new DownArrow(), 825, 100);
            }
            else if (met1 == 50)
            {
                getWorld().addObject(new LeftArrow(), 675, 100);
            }
            else if (met1 == 70)
            {
                getWorld().addObject(new Three(), 975, 100);
            }
            else if (met1 == 80)
            {
                getWorld().addObject(new One(), 675, 100);
            }
            else if (met1 == 100)
            {
                getWorld().addObject(new UpArrow(), 975, 100);
            }
            else if (met1 == 120)
            {
                getWorld().addObject(new DownArrow(), 825, 100);
            }
            else if (met1 == 160)
            {
                met1 = 0;
                sequenceCount += 1;
                sequence = Greenfoot.getRandomNumber(3) + 1;
            }
        }
        
        /* statements:
         * 
         *      if (met1 == )
                {
                    getWorld().addObject(new One(), 675, 100);
                }
                else if (met1 == )
                {
                    getWorld().addObject(new Two(), 825, 100);
                }
                else if (met1 == )
                {
                    getWorld().addObject(new Three(), 975, 100);
                }
                else if (met1 == )
                {
                    getWorld().addObject(new Four(), 1125, 100);
                }
                else if (met1 == )
                {
                    getWorld().addObject(new LeftArrow(), 675, 100);
                }
                else if (met1 == )
                {
                    getWorld().addObject(new DownArrow(), 825, 100);
                }
                else if (met1 == )
                {
                    getWorld().addObject(new UpArrow(), 975, 100);
                }
                else if (met1 == )
                {
                    getWorld().addObject(new RightArrow(), 1125, 100);
                }
         * 
         * 
         * /
         */
}
