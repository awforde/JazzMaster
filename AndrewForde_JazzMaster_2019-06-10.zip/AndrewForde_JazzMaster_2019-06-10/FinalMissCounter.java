import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FinalMissCounter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FinalMissCounter extends Actor
{
    int finalMisses = 0;
    
    protected  void addedToWorld (World MyWorld)
    {
        MyWorld myWorld = (MyWorld) getWorld(); // get a reference to the world
        MissCounter missCounter = myWorld.getMisses();   // get a reference to the hit counter
        finalMisses = missCounter.getMissesValue(); // set the final hits to the value of the hit counter
        setImage (new GreenfootImage("Misses: " + finalMisses, 50, Color.WHITE, Color.GRAY));
    }  
}
