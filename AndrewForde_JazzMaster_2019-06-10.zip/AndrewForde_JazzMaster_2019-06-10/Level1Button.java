import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level1Button here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level1Button extends Actor
{
    
    public void act() 
    {
        if (Greenfoot.mouseClicked(this)) // if the button is clicked,
        {
            // change to the song select screen
            getWorld().setBackground(new GreenfootImage("JazzMaster_SongScreen.png"));
            
            getWorld().removeObjects(getWorld().getObjects(BackToStartMenu.class)); // remove the back button
            
            //add song actor
            getWorld().addObject(new Level1Song(), 300, 525);
            getWorld().addObject(new HitBar(), 900, 800);
            getWorld().addObject(new EnterToStart(), 900, 300);
            
            getWorld().removeObject(this); // remove the button LAST!!!
            
        }
    }    
}
