import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HitCounter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HitCounter extends Actor
{
    private int totalHits = 0; // create a private integer, recording the hits
  
    public HitCounter()
    {
        setImage (new GreenfootImage("Hits: " + totalHits, 50, Color.WHITE, Color.DARK_GRAY)); // displays the hits
    }
    
    public int getHitsValue() // used to reference the total number of hits
    {
        return totalHits;
    }
    
    
    public void currentHits(int addedHits) // updates the hits counter with addedHits
    {
        totalHits += addedHits; // set the new hits to the previous hits plus the added hits
        setImage (new GreenfootImage ("Hits: " + totalHits, 50, Color.WHITE, Color.DARK_GRAY)); // update the hit counter
    }  
}
