import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Four here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Four extends Actor
{
    public void act() 
    {
        if (getY() > 890) // if we have reached the end of the screen
        {
            increaseScore(-2); // decrease the score by 2
            increaseMisses(1); // increase the miss counter by 1
            getWorld().removeObject(this); // remove the icon
        }
        else 
        { 
            setLocation(getX(), getY()+10); //move the icon down on the screen
        }
    }    
    
    public void increaseMisses(int addedMisses)
    {
        MyWorld myWorld = (MyWorld) getWorld(); // get a reference to the world
        MissCounter missCounter = myWorld.getMisses();   // get a reference to the miss counter
        missCounter.currentMisses(addedMisses);        // increase misses by added miss amount
    }
    public void increaseScore(int addedScore)
    {
        MyWorld myWorld = (MyWorld) getWorld(); // get a reference to the world
        ScoreCounter scoreCounter = myWorld.getScore();   // get a reference to the score counter
        scoreCounter.currentScore(addedScore);        // increase score by added score amount
    }   
}
