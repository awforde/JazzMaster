import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HitBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HitBar extends Actor
{
    boolean leftKeyPressed = false;
    boolean downKeyPressed = false;
    boolean upKeyPressed = false;
    boolean rightKeyPressed = false;
    
    boolean oneKeyPressed = false;
    boolean twoKeyPressed = false;
    boolean threeKeyPressed = false;
    boolean fourKeyPressed = false;
    
    /**
     * Act - do whatever the HitBar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        Actor leftArrow = getOneIntersectingObject(LeftArrow.class); // used to reference left arrows touching the hit bar
        Actor downArrow = getOneIntersectingObject(DownArrow.class); // used to reference down arrows touching the hit bar
        Actor upArrow = getOneIntersectingObject(UpArrow.class); // used to reference up arrows touching the hit bar
        Actor rightArrow = getOneIntersectingObject(RightArrow.class); // used to reference right arrows touching the hit bar
        
        Actor one = getOneIntersectingObject(One.class); // used to reference ones touching the hit bar
        Actor two = getOneIntersectingObject(Two.class); // used to reference twos touching the hit bar
        Actor three = getOneIntersectingObject(Three.class); // used to reference threes touching the hit bar
        Actor four = getOneIntersectingObject(Four.class); // used to reference fours touching the hit bar
        
        if (Greenfoot.isKeyDown("left") && leftKeyPressed == false) // if the left arrow is pressed, and has been previously released
        {
            if (leftArrow != null)
            {
                //we are touching a left arrow
                getWorld().removeObject(leftArrow);
                Greenfoot.playSound("SaxophoneLeft.mp3");
                increaseHits(1); // increase hits by 1
                increaseScore(10); // increase score by 10
            }
            else
            {
                //decrease score
                Greenfoot.playSound("SaxophoneLeftMiss.mp3");
                increaseMisses(1); // update the miss counter
                increaseScore(-5); // decrease score by 5
            }
            leftKeyPressed = true; // the key is now pressed, and must be released
        }
        else if (Greenfoot.isKeyDown("left") == false) // when the key is not pressed
        {
            leftKeyPressed = false; // the key is released
        }
        if (Greenfoot.isKeyDown("down") && downKeyPressed == false) // if the down arrow is pressed, and has been previously released
        {
            if (downArrow != null)// if the hit bar is touching a down arrow, and the key has been pressed
            {
                //we are touching a down arrow
                getWorld().removeObject(downArrow);//remove the down arrow
                Greenfoot.playSound("SaxophoneDown.mp3"); // play the correct sound
                increaseScore(10); // increase score by 10
                increaseHits(1); // increase hits by 1
            }
            else // we have pressed the button, but there is no arrow touching the bar
            {
                Greenfoot.playSound("SaxophoneDownMiss.mp3");
                increaseScore(-5); // decrease score by 5
                increaseMisses(1); // update the miss counter
            }
            downKeyPressed = true; // the key is now pressed, and must be released
        }
        else if (Greenfoot.isKeyDown("down") == false) // when the key is not pressed
        {
            downKeyPressed = false; // the key is released
        }
        if (Greenfoot.isKeyDown("up") && upKeyPressed == false) // if the up arrow is pressed, and has been previously released
        {
            if (upArrow != null)// if the hit bar is touching an up arrow, and the key has been pressed
            {
                //we are touching an up arrow
                getWorld().removeObject(upArrow);//remove the up arrow
                Greenfoot.playSound("SaxophoneUp.mp3"); // play the correct sound
                increaseScore(10); // increase score by 10
                increaseHits(1); // increase hits by 1
            }
            else // we have pressed the button, but there is no arrow touching the bar
            {
                Greenfoot.playSound("SaxophoneUpMiss.mp3");
                increaseScore(-5); // decrease score by 5
                increaseMisses(1); // update the miss counter
            }
            upKeyPressed = true; // the key is now pressed, and must be released
        }
        else if (Greenfoot.isKeyDown("up") == false) // when the key is not pressed
        {
            upKeyPressed = false; // the key is released
        }
        if (Greenfoot.isKeyDown("right") && rightKeyPressed == false) // if the right arrow is pressed, and has been previously released
        {
            if (rightArrow != null)// if the hit bar is touching a right arrow, and the key has been pressed
            {
                //we are touching a right arrow
                getWorld().removeObject(rightArrow);//remove the right arrow
                Greenfoot.playSound("SaxophoneRight.mp3"); // play the correct sound
                increaseScore(10); // increase score by 10
                increaseHits(1); // increase hits by 1
            }
            else // we have pressed the button, but there is no arrow touching the bar
            {
                Greenfoot.playSound("SaxophoneRightMiss.mp3");
                increaseScore(-5); // decrease score by 5
                increaseMisses(1); // update the miss counter
            }
            rightKeyPressed = true; // the key is now pressed, and must be released
        }
        else if (Greenfoot.isKeyDown("right") == false) // when the key is not pressed
        {
            rightKeyPressed = false; // the key is released
        }
        
        if (Greenfoot.isKeyDown("1") && oneKeyPressed == false) // if the one is pressed, and has been previously released
        {
            if (one != null)
            {
                //we are touching a one
                getWorld().removeObject(one);
                Greenfoot.playSound("Saxophone1.mp3");// play the correct sound
                increaseScore(10); // increase score by 10
                increaseHits(1); // increase hits by 1
            }
            else
            {
                Greenfoot.playSound("Saxophone1Miss.mp3");
                increaseScore(-5); // decrease score by 5
                increaseMisses(1); // update the miss counter
            }
            oneKeyPressed = true; // the key is now pressed, and must be released
        }
        else if (Greenfoot.isKeyDown("1") == false) // when the key is not pressed
        {
            oneKeyPressed = false; // the key is released
        }
        if (Greenfoot.isKeyDown("2") && twoKeyPressed == false) // if the two is pressed, and has been previously released
        {
            if (two != null)
            {
                //we are touching a two
                getWorld().removeObject(two); // remove the two
                Greenfoot.playSound("Saxophone2.mp3");// play the correct sound
                increaseScore(10); // increase score by 10
                increaseHits(1); // increase hits by 1
            }
            else
            {
                Greenfoot.playSound("Saxophone2Miss.mp3");
                increaseScore(-5); // decrease score by 5
                increaseMisses(1); // update the miss counter
            }
            twoKeyPressed = true; // the key is now pressed, and must be released
        }
        else if (Greenfoot.isKeyDown("2") == false) // when the key is not pressed
        {
            twoKeyPressed = false; // the key is released
        }
        if (Greenfoot.isKeyDown("3") && threeKeyPressed == false) // if the three is pressed, and has been previously released
        {
            if (three != null)
            {
                //we are touching a three
                getWorld().removeObject(three); // remove the three
                Greenfoot.playSound("Saxophone3.mp3"); // play the correct sound
                increaseScore(10); // increase score by 10
                increaseHits(1); // increase hits by 1
            }
            else
            {
                Greenfoot.playSound("Saxophone3Miss.mp3");
                increaseScore(-5); // decrease score by 5
                increaseMisses(1); // update the miss counter
            }
            threeKeyPressed = true; // the key is now pressed, and must be released
        }
        else if (Greenfoot.isKeyDown("3") == false) // when the key is not pressed
        {
            threeKeyPressed = false; // the key is released
        }
        if (Greenfoot.isKeyDown("4") && fourKeyPressed == false) // if the four is pressed, and has been previously released
        {
            if (four != null)
            {
                //we are touching a four
                getWorld().removeObject(four);// remove the four
                Greenfoot.playSound("Saxophone4.mp3"); // play the correct sound
                increaseScore(10); // increase score by 10
                increaseHits(1); // increase hits by 1
            }
            else
            {
                Greenfoot.playSound("Saxophone4Miss.mp3");
                increaseScore(-5); // decrease score by 5
                increaseMisses(1); // update the miss counter
            }
            fourKeyPressed = true; // the key is now pressed, and must be released
        }
        else if (Greenfoot.isKeyDown("4") == false) // when the key is not pressed
        {
            fourKeyPressed = false; // the key is released
        }
    }    
    
    public void increaseScore(int addedScore)
    {
        MyWorld myWorld = (MyWorld) getWorld(); // get a reference to the world
        ScoreCounter scoreCounter = myWorld.getScore();   // get a reference to the score counter
        scoreCounter.currentScore(addedScore);        // increase score by added score amount
    }
    public void increaseHits(int addedHits)
    {
        MyWorld myWorld = (MyWorld) getWorld(); // get a reference to the world
        HitCounter hitCounter = myWorld.getHits();   // get a reference to the hit counter
        hitCounter.currentHits(addedHits);        // increase hits by added hit amount
    }
    public void increaseMisses(int addedMisses)
    {
        MyWorld myWorld = (MyWorld) getWorld(); // get a reference to the world
        MissCounter missCounter = myWorld.getMisses();   // get a reference to the miss counter
        missCounter.currentMisses(addedMisses);        // increase misses by added miss amount
    }
}
