import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FinalHitCounter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FinalHitCounter extends Actor
{
    int finalHits = 0;
    
    protected  void addedToWorld (World MyWorld)
    {
        MyWorld myWorld = (MyWorld) getWorld(); // get a reference to the world
        HitCounter hitCounter = myWorld.getHits();   // get a reference to the hit counter
        finalHits = hitCounter.getHitsValue(); // set the final hits to the value of the hit counter
        setImage (new GreenfootImage("Hits: " + finalHits, 50, Color.WHITE, Color.GRAY));
    }  
}
