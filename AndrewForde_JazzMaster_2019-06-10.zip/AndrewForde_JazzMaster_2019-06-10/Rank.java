import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Rank here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rank extends Actor
{
    int finalScore = 0; // the final score value will be used to calculate the player's rank
    
    protected  void addedToWorld (World MyWorld)
    {
        MyWorld myWorld = (MyWorld) getWorld(); // get a reference to the world
        ScoreCounter scoreCounter = myWorld.getScore();   // get a reference to the score counter
        finalScore = scoreCounter.getScoreValue(); // set the final score to the value of the score counter
        
        if (finalScore < 300) // if the player gets a score less than 99, their rank will be Junior
        {
            setImage (new GreenfootImage("Rank: Junior", 50, Color.WHITE, Color.GRAY));
        }
        else if (finalScore >= 300 && finalScore < 599)// if the player gets a score of 100-199, their rank will be Amateur
        {
            setImage (new GreenfootImage("Rank: Amateur", 50, Color.WHITE, Color.GRAY)); 
        }
        else if (finalScore >= 600 && finalScore < 799)// if the player gets a score of 200-499, their rank will be Professional
        {
            setImage (new GreenfootImage("Rank: Professional", 50, Color.WHITE, Color.GRAY));
        }
        else if (finalScore >= 800)// if the player gets a score greater than 500, their rank will be Jazz Master
        {
            setImage (new GreenfootImage("Rank: Jazz Master", 50, Color.WHITE, Color.GRAY));
        }
    }  
}
