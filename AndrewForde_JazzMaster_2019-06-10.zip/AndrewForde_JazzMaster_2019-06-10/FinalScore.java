import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FinalScore here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FinalScore extends Actor
{
    int finalScore = 0;
    
    protected  void addedToWorld (World MyWorld)
    {
        MyWorld myWorld = (MyWorld) getWorld(); // get a reference to the world
        ScoreCounter scoreCounter = myWorld.getScore();   // get a reference to the score counter
        finalScore = scoreCounter.getScoreValue(); // set the final score to the value of the score counter
        setImage (new GreenfootImage("Final Score: " + finalScore, 75, Color.WHITE, Color.GRAY));
    }
}
