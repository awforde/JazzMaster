import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LetsRockButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LetsRockButton extends Actor
{
    /**
     * Act - do whatever the LetsRockButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (Greenfoot.mouseClicked(this)) // if the button is clicked,
        {
            // change to the song select screen
            getWorld().setBackground(new GreenfootImage("JazzMaster_SongSelectScreen.png"));
            
            getWorld().removeObjects(getWorld().getObjects(HowToPlayButton.class));// remove the how to play button
            getWorld().removeObjects(getWorld().getObjects(CreditsButton.class)); // remove the credits button
            
            //add song buttons
            getWorld().addObject(new Level1Button(), 900, 300);
            
            getWorld().addObject(new BackToStartMenu(), 1100, 850);
            
            getWorld().removeObject(this); // remove the button LAST!!!
            
        }
    }    
}
