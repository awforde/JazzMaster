import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BackToStartMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BackToStartMenu extends Actor
{
    /**
     * Act - do whatever the BackToStartMenu wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (Greenfoot.mouseClicked(this)) // if the button is clicked,
        {
            //chnage to the start menu screen
            getWorld().setBackground(new GreenfootImage("JazzMaster_TitleMenu.png"));
            
            getWorld().addObject(new LetsRockButton(), 900,350);// add the song select button
            getWorld().addObject(new HowToPlayButton(), 900, 500); // add the how to play button
            getWorld().addObject(new CreditsButton(), 900, 650); // add the credits button
            
            //remove song buttons
            
            getWorld().removeObjects(getWorld().getObjects(Level1Button.class)); // remove level 1
            
            // remove buttons and actors from the score screen
            getWorld().removeObjects(getWorld().getObjects(FinalScore.class));
            getWorld().removeObjects(getWorld().getObjects(FinalHitCounter.class));
            getWorld().removeObjects(getWorld().getObjects(FinalMissCounter.class));
            getWorld().removeObjects(getWorld().getObjects(Rank.class));
            
            getWorld().removeObject(this); // remove the button LAST!!!
            
        }
    }    
}
