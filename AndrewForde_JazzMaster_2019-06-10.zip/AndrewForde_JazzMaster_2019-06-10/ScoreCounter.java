import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ScoreCounter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScoreCounter extends Actor
{
    private int totalScore = 0; // create a private integer, recording the score
  
    public ScoreCounter()
    {
        setImage (new GreenfootImage("Score: " + totalScore, 75, Color.WHITE, Color.DARK_GRAY)); // displays the score
    }
    
    public int getScoreValue() // used to reference the total score
    {
        return totalScore;
    }
    
    
    public void currentScore(int addedScore) // updates the score with addedScore
    {
        totalScore += addedScore; // set the new score to the previous score plus the added score
        setImage (new GreenfootImage ("Score: " + totalScore, 75, Color.WHITE, Color.DARK_GRAY)); // update the score counter
    }  
}
