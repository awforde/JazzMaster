import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MissCounter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MissCounter extends Actor
{
    private int totalMisses = 0; // create a private integer, recording the misses
  
    public MissCounter()
    {
        setImage (new GreenfootImage("Misses: " + totalMisses, 50, Color.WHITE, Color.DARK_GRAY)); // displays the misses
    }
    
    public int getMissesValue() // used to reference the total number of misses
    {
        return totalMisses;
    }
    
    
    public void currentMisses(int addedMisses) // updates the misses counter with addedMisses
    {
        totalMisses += addedMisses; // set the new misses to the previous misses plus the added misses
        setImage (new GreenfootImage ("Misses: " + totalMisses, 50, Color.WHITE, Color.DARK_GRAY)); // update the misses counter
    }     
}
