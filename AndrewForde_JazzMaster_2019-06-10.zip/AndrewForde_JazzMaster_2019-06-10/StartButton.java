import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class StartButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StartButton extends Actor
{
    /**
     * Act - do whatever the StartButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (Greenfoot.mouseClicked(this)) // if the button is clicked,
        {
            //change to the start menu screen
            getWorld().setBackground(new GreenfootImage("JazzMaster_TitleMenu.png"));
            
            getWorld().addObject(new LetsRockButton(), 900,350);// add the song select button
            getWorld().addObject(new HowToPlayButton(), 900, 500); // add the how to play button
            getWorld().addObject(new CreditsButton(), 900, 650); // add the credits button
            
            getWorld().removeObject(this); // remove the button LAST!!!
            
        }
    }    
    
}
