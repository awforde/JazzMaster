import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnterToStart here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnterToStart extends Actor
{
    public EnterToStart()
    {
        setImage (new GreenfootImage("Press Enter To Start", 50, Color.WHITE, Color.GRAY));
    }
    public void act()
    {
        if (Greenfoot.isKeyDown("enter")) // if the enter button is pressed, remove this text object
        {
            getWorld().removeObject(this);
        }
    }
}
