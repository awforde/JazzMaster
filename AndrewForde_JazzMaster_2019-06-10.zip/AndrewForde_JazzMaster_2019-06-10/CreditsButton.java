import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CreditsButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CreditsButton extends Actor
{
    /**
     * Act - do whatever the CreditsButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (Greenfoot.mouseClicked(this)) // if the credits button is clicked,
        {
            //add the credits screen without removing anything else
            getWorld().addObject(new CreditsScreen(), (getWorld().getWidth())/2,(getWorld().getHeight())/2);
        }
    }    
}
